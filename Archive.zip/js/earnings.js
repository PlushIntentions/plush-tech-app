// ===============================
//        LOAD EARNINGS
// ===============================
async function loadEarnings() {
    const { data } = await supabase
        .from("earnings")
        .select("*, jobs(title)")
        .eq("technician_id", TECH_ID)
        .order("created_at", { ascending: false });

    renderEarnings(data);
}


// ===============================
//       RENDER EARNINGS
// ===============================
function renderEarnings(list) {
    const summary = document.getElementById("earningsSummary");
    const container = document.getElementById("earningsList");

    let total = 0;
    container.innerHTML = "";

    list.forEach(e => {
        total += Number(e.amount);

        const item = document.createElement("div");
        item.classList.add("job-card");
        item.innerHTML = `
            <strong>${e.jobs.title}</strong><br>
            Earned: $${e.amount}
        `;
        container.appendChild(item);
    });

    summary.innerHTML = `<h3>Total: $${total.toFixed(2)}</h3>`;
}

loadEarnings();
