let currentJob = null;

// ===============================
//         LOAD JOBS
// ===============================
async function loadJobs() {
    const { data, error } = await supabase
        .from("jobs")
        .select("*")
        .order("created_at", { ascending: false });

    if (error) return console.error(error);

    renderJobs(data);
}


// ===============================
//       RENDER JOB CARDS
// ===============================
function renderJobs(jobs) {
    const list = document.getElementById("jobList");
    list.innerHTML = "";

    jobs.forEach(job => {
        const card = document.createElement("div");
        card.classList.add("job-card");

        card.innerHTML = `
            <strong>${job.title}</strong><br>
            ${job.address}<br>
            <small>${job.status}</small>
        `;

        card.onclick = () => openJobModal(job);
        list.appendChild(card);
    });
}

loadJobs();
