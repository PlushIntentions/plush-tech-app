// ===============================
//     LOAD NOTIFICATIONS
// ===============================
async function loadNotifications() {
    const { data } = await supabase
        .from("notifications")
        .select("*")
        .eq("technician_id", TECH_ID)
        .order("created_at", { ascending: false });

    renderNotifications(data);
}


// ===============================
//     RENDER NOTIFICATIONS
// ===============================
function renderNotifications(notes) {
    const list = document.getElementById("notificationList");
    const badge = document.getElementById("notificationBadge");

    list.innerHTML = "";
    let unread = 0;

    notes.forEach(n => {
        if (!n.read) unread++;

        const item = document.createElement("div");
        item.classList.add("notification-item");
        item.innerHTML = `<strong>${n.title}</strong>`;
        list.appendChild(item);
    });

    if (unread > 0) {
        badge.textContent = unread;
        badge.classList.remove("hidden");
    } else {
        badge.classList.add("hidden");
    }
}


// ===============================
//     REALTIME LISTENER
// ===============================
supabase
    .channel("notifications")
    .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications" },
        payload => loadNotifications()
    )
    .subscribe();

loadNotifications();
