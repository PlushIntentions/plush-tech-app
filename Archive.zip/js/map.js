mapboxgl.accessToken = "pk.eyJ1IjoicGx1c2gtaW50ZW50aW9ucyIsImEiOiJjbXAwNXEydWoxNDdjNDhva2tjc3puMzE4In0.RuR9Ze9VVEXFsy1jFy9X1g";

const map = new mapboxgl.Map({
    container: "map",
    style: "mapbox://styles/mapbox/dark-v11",
    center: [-84.19, 39.76],
    zoom: 11
});
