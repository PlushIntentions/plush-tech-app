// ===============================
//         OPEN JOB MODAL
// ===============================
function openJobModal(job) {
    currentJob = job;

    document.getElementById("modalTitle").textContent = job.title;
    document.getElementById("modalAddress").textContent = job.address;
    document.getElementById("modalDescription").textContent = job.description;
    document.getElementById("modalTools").textContent = "Tools: " + job.tools;
    document.getElementById("modalPay").textContent = "Pay: $" + job.pay;

    document.getElementById("acceptJob").classList.toggle("hidden", job.status !== "NEW");
    document.getElementById("declineJob").classList.toggle("hidden", job.status !== "NEW");
    document.getElementById("startJob").classList.toggle("hidden", job.status !== "ACCEPTED");
    document.getElementById("completeJob").classList.toggle("hidden", job.status !== "IN_PROGRESS");

    document.getElementById("jobModal").classList.remove("hidden");
}


// ===============================
//         CLOSE MODAL
// ===============================
function closeJobModal() {
    document.getElementById("jobModal").classList.add("hidden");
}


// ===============================
//         JOB ACTIONS
// ===============================
document.getElementById("acceptJob").onclick = async () => {
    await supabase.from("jobs").update({ status: "ACCEPTED" }).eq("id", currentJob.id);
    closeJobModal();
    loadJobs();
};

document.getElementById("declineJob").onclick = async () => {
    await supabase.from("jobs").update({ status: "DECLINED" }).eq("id", currentJob.id);
    closeJobModal();
    loadJobs();
};

document.getElementById("startJob").onclick = async () => {
    await supabase.from("jobs").update({ status: "IN_PROGRESS" }).eq("id", currentJob.id);
    closeJobModal();
    loadJobs();
};

document.getElementById("completeJob").onclick = async () => {
    await supabase.from("jobs").update({ status: "COMPLETED" }).eq("id", currentJob.id);
    closeJobModal();
    loadJobs();
};
