// ===============================
//     LOAD TECHNICIAN PROFILE
// ===============================
async function loadTechnicianProfile() {
    const { data } = await supabase
        .from("technicians")
        .select("*")
        .eq("id", TECH_ID)
        .single();

    techName.value = data.name || "";
    techPhone.value = data.phone || "";
    techEmail.value = data.email || "";
    techSkills.value = data.skills || "";
    techRadius.value = data.radius || 25;
    radiusValue.textContent = `${data.radius} miles`;
}


// ===============================
//     SAVE PROFILE
// ===============================
saveProfile.onclick = async () => {
    const updates = {
        name: techName.value,
        phone: techPhone.value,
        email: techEmail.value,
        skills: techSkills.value,
        radius: techRadius.value
    };

    await supabase.from("technicians").update(updates).eq("id", TECH_ID);
    alert("Profile updated");
};


// ===============================
//     RADIUS SLIDER
// ===============================
techRadius.oninput = e => {
    radiusValue.textContent = `${e.target.value} miles`;
};

loadTechnicianProfile();
