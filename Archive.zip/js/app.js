// ===============================
//       SUPABASE INIT
// ===============================
const supabase = supabase.createClient(
    "https://gsneugdwoxpibajghwge.supabase.co",
    "sb_publishable_bbsF43-TXGgEumRGflGf5A_apC1dP3T"
);

// Technician ID
const TECH_ID = "TECHNICIAN_ID";


// ===============================
//        TAB SWITCHING
// ===============================
function openTab(tabName) {
    document.querySelectorAll(".tab-content").forEach(tab => {
        tab.classList.add("hidden");
    });

    document.querySelectorAll(".nav-pill").forEach(btn => {
        btn.classList.remove("active");
    });

    document.getElementById(tabName).classList.remove("hidden");
    document.querySelector(`[data-tab="${tabName}"]`).classList.add("active");

    if (tabName === "jobs") {
        setTimeout(() => map.resize(), 200);
    }
}


// ===============================
//     NOTIFICATION DROPDOWN
// ===============================
document.getElementById("notificationBell").onclick = () => {
    document.getElementById("notificationDropdown").classList.toggle("hidden");
};
